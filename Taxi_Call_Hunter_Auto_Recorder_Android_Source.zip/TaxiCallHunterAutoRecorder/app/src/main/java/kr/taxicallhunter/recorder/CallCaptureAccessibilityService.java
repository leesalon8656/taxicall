package kr.taxicallhunter.recorder;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.content.Context;
import android.content.SharedPreferences;
import android.location.Location;
import android.location.LocationManager;
import android.os.Build;
import android.os.CancellationSignal;
import android.os.Handler;
import android.os.Looper;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.graphics.Rect;
import android.content.pm.PackageManager;
import android.Manifest;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.BufferedWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.Executor;

public class CallCaptureAccessibilityService extends AccessibilityService {
    private static final long COOLDOWN_MS=2500;
    private long lastSavedAt=0;
    private String lastSignature="";
    private final Handler handler=new Handler(Looper.getMainLooper());
    private static final Executor MAIN= command -> new Handler(Looper.getMainLooper()).post(command);

    @Override public void onServiceConnected(){ AccessibilityServiceInfo i=getServiceInfo(); i.eventTypes=AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED|AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED|AccessibilityEvent.TYPE_VIEW_SCROLLED; i.feedbackType=AccessibilityServiceInfo.FEEDBACK_GENERIC; i.flags|=AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS|AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS; i.notificationTimeout=120; setServiceInfo(i); }
    @Override public void onAccessibilityEvent(AccessibilityEvent event){
        if(event==null)return;
        CharSequence pkgCs=event.getPackageName(); if(pkgCs==null)return; String pkg=pkgCs.toString();
        if(pkg.equals(getPackageName()))return;
        SharedPreferences p=getSharedPreferences("capture",MODE_PRIVATE); String target=p.getString("target_pkg",""); if(!target.isEmpty()&&!target.equals(pkg))return;
        AccessibilityNodeInfo root=getRootInActiveWindow(); if(root==null)return;
        Hit hit=findAccept(root,0); if(hit==null){ if(target.equals(pkg)){ lastSignature=""; lastSavedAt=0; } return; }
        long now=System.currentTimeMillis(); String sig=pkg+":"+hit.bounds;
        if(now-lastSavedAt<COOLDOWN_MS && sig.equals(lastSignature))return;
        // First encounter is staged as a candidate. User confirms the package while safely parked.
        p.edit().putString("candidate_pkg",pkg).putString("candidate_label",pkg).apply();
        if(target.isEmpty())return;
        lastSavedAt=now; lastSignature=sig;
        captureLocationAndWrite(pkg,hit.bounds,now);
    }
    private static class Hit { String bounds; Hit(String b){bounds=b;} }
    private Hit findAccept(AccessibilityNodeInfo node,int depth){
        if(node==null||depth>18)return null;
        CharSequence t=node.getText(), d=node.getContentDescription();
        String text=(t==null?"":t.toString()).trim(), desc=(d==null?"":d.toString()).trim();
        boolean label=text.equals("수락")||desc.equals("수락")||text.contains("수락하기")||desc.contains("수락하기");
        if(label){ AccessibilityNodeInfo clickable=node; if(!node.isClickable()&&node.getParent()!=null&&node.getParent().isClickable())clickable=node.getParent(); Rect r=new Rect(); clickable.getBoundsInScreen(r); if(r.width()>0&&r.height()>0)return new Hit(r.flattenToString()); }
        for(int i=0;i<node.getChildCount();i++){ AccessibilityNodeInfo child=node.getChild(i); Hit h=findAccept(child,depth+1); if(child!=null)child.recycle(); if(h!=null)return h; }
        return null;
    }
    private void captureLocationAndWrite(String pkg,String bounds,long time){
        if(Build.VERSION.SDK_INT<30){writeRow(pkg,bounds,time,null);return;}
        if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)!=PackageManager.PERMISSION_GRANTED){writeRow(pkg,bounds,time,null);return;}
        LocationManager lm=(LocationManager)getSystemService(LOCATION_SERVICE);
        try {
            String provider=checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED?LocationManager.GPS_PROVIDER:LocationManager.NETWORK_PROVIDER;
            CancellationSignal cs=new CancellationSignal(); handler.postDelayed(cs::cancel,12000);
            lm.getCurrentLocation(provider,cs,MAIN,loc->{ if(loc==null){ Location fallback=null; try{fallback=lm.getLastKnownLocation(provider);}catch(SecurityException ignored){} writeRow(pkg,bounds,time,fallback);}else writeRow(pkg,bounds,time,loc); });
        }catch(Exception e){writeRow(pkg,bounds,time,null);}
    }
    private synchronized void writeRow(String pkg,String bounds,long time,Location loc){
        try{ File f=logFile(this); boolean fresh=!f.exists()||f.length()==0; try(BufferedWriter w=new BufferedWriter(new OutputStreamWriter(new FileOutputStream(f,true),"UTF-8"))){ if(fresh)w.write("\uFEFFtime,kind,area,lat,lon\n"); String iso=new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX",Locale.US).format(new Date(time)); String lat=loc==null?"":Double.toString(loc.getLatitude()), lon=loc==null?"":Double.toString(loc.getLongitude()); w.write(csv(iso)+",\"콜 발생\",\"\","+csv(lat)+","+csv(lon)+"\n"); }}catch(Exception ignored){}
    }
    private String csv(String s){return "\""+(s==null?"":s.replace("\"","\"\""))+"\"";}
    public static File logFile(Context c){return new File(c.getFilesDir(),"taxi_call_auto_log.csv");}
    public static int count(Context c){File f=logFile(c);if(!f.exists())return 0;try(java.io.BufferedReader r=new java.io.BufferedReader(new java.io.FileReader(f))){int n=-1;while(r.readLine()!=null)n++;return Math.max(0,n);}catch(Exception e){return 0;}}
    @Override public void onInterrupt(){}
}
