package kr.taxicallhunter.recorder;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;

public class LocationKeepService extends Service {
    private static final String CHANNEL="taxi_capture_location";
    @Override public void onCreate(){super.onCreate(); if(Build.VERSION.SDK_INT>=26){NotificationManager nm=getSystemService(NotificationManager.class); nm.createNotificationChannel(new NotificationChannel(CHANNEL,"택시 콜 위치 기록",NotificationManager.IMPORTANCE_LOW)); Notification n=new Notification.Builder(this,CHANNEL).setContentTitle("택시 콜 헌터 자동기록 실행 중").setContentText("신규 콜 화면을 감지하면 GPS 위치를 저장합니다.").setSmallIcon(android.R.drawable.ic_menu_mylocation).build(); if(Build.VERSION.SDK_INT>=29)startForeground(7,n,android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION);else startForeground(7,n);} }
    @Override public int onStartCommand(Intent i,int f,int id){return START_STICKY;}
    @Override public IBinder onBind(Intent i){return null;}
}
