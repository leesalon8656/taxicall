package kr.taxicallhunter.recorder;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.io.File;
import java.io.FileInputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private static final int REQ_PERMS = 41;
    private static final int CREATE_CSV = 42;
    private TextView status;
    private SharedPreferences prefs;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("capture", MODE_PRIVATE);
        LinearLayout root = new LinearLayout(this); root.setOrientation(1); root.setPadding(28, 30, 28, 24);
        TextView title = new TextView(this); title.setText("🚕 택시 콜 헌터 자동기록"); title.setTextSize(23); title.setTextColor(0xff17202a); title.setPadding(0,0,0,16); root.addView(title);
        TextView desc = new TextView(this); desc.setText("카카오T 신규 콜 화면에 나타나는 ‘수락’ 버튼을 감지하고, 그 순간의 GPS와 시각을 기록합니다. 화면을 누르거나 콜을 수락하지 않습니다."); desc.setTextSize(16); desc.setTextColor(0xff394b59); desc.setPadding(0,0,0,18); root.addView(desc);
        status = new TextView(this); status.setTextSize(14); status.setTextColor(0xff145a32); status.setPadding(0,0,0,18); root.addView(status);
        addButton(root, "1. 위치 권한 허용", v -> requestLoc());
        addButton(root, "2. 콜 감지 접근성 켜기", v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        addButton(root, "3. 위치 기록 서비스 시작", v -> startLocationService());
        addButton(root, "감지된 앱을 카카오T로 지정", v -> lockCandidate());
        addButton(root, "대상 앱 지정 초기화", v -> { prefs.edit().remove("target_pkg").apply(); refresh(); });
        addButton(root, "콜 기록 CSV 내보내기", v -> createCsv());
        TextView note = new TextView(this); note.setText("설정 순서: 위치 권한 허용 → 접근성에서 ‘택시 콜 감지 서비스’ 켜기 → 위치 기록 서비스 시작. 처음 수락 버튼이 감지되면 앱 이름이 후보로 표시됩니다. 안전하게 정차한 뒤 ‘감지된 앱을 카카오T로 지정’을 눌러주세요."); note.setTextSize(13); note.setTextColor(0xff5d6d7e); note.setPadding(0,18,0,0); root.addView(note);
        setContentView(root); refresh();
    }
    private void addButton(LinearLayout root, String label, View.OnClickListener l) { Button b = new Button(this); b.setText(label); b.setAllCaps(false); b.setTextSize(15); b.setOnClickListener(l); LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1,-2); p.bottomMargin=8; root.addView(b,p); }
    private void requestLoc() {
        if (Build.VERSION.SDK_INT >= 23) requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.POST_NOTIFICATIONS}, REQ_PERMS);
    }
    @Override public void onRequestPermissionsResult(int r, String[] p, int[] g) { super.onRequestPermissionsResult(r,p,g); refresh(); }
    private void startLocationService() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)!=PackageManager.PERMISSION_GRANTED) { requestLoc(); return; }
        Intent i = new Intent(this, LocationKeepService.class); if (Build.VERSION.SDK_INT>=26) startForegroundService(i); else startService(i); Toast.makeText(this,"위치 기록 서비스를 시작했습니다.",Toast.LENGTH_SHORT).show(); refresh();
    }
    private void lockCandidate() {
        String candidate=prefs.getString("candidate_pkg", "");
        if (candidate.isEmpty()) { Toast.makeText(this,"아직 ‘수락’ 버튼을 감지한 앱이 없습니다. 카카오T 콜 화면이 한 번 나타난 뒤 확인하세요.",Toast.LENGTH_LONG).show(); return; }
        prefs.edit().putString("target_pkg",candidate).apply(); Toast.makeText(this,"감지 대상 앱 지정 완료: "+candidate,Toast.LENGTH_LONG).show(); refresh();
    }
    private void refresh() {
        String target=prefs.getString("target_pkg", "미지정"), candidate=prefs.getString("candidate_pkg", "아직 없음");
        status.setText("감지 대상: "+target+"\n마지막 수락 버튼 후보: "+candidate+"\n저장된 콜: "+CallCaptureAccessibilityService.count(this)+"건\n위치 권한: "+(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED?"정밀 위치 허용":"미허용"));
    }
    private void createCsv() { Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("text/csv"); i.putExtra(Intent.EXTRA_TITLE,"taxi_call_auto_log.csv"); startActivityForResult(i,CREATE_CSV); }
    @Override protected void onActivityResult(int r,int c,Intent d) { super.onActivityResult(r,c,d); if(r==CREATE_CSV&&c==RESULT_OK&&d!=null){ try(OutputStream out=getContentResolver().openOutputStream(d.getData()); FileInputStream in=new FileInputStream(CallCaptureAccessibilityService.logFile(this))){ byte[] buf=new byte[8192]; int n; while((n=in.read(buf))>0)out.write(buf,0,n); Toast.makeText(this,"CSV 저장 완료. 택시 콜 헌터 V9의 ‘CSV 불러오기’에서 가져오세요.",Toast.LENGTH_LONG).show(); }catch(Exception e){Toast.makeText(this,"내보내기 실패: "+e.getMessage(),Toast.LENGTH_LONG).show();}} refresh(); }
    @Override protected void onResume(){super.onResume();if(status!=null)refresh();}
}
